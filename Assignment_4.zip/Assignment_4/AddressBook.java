package Assignment_4;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class AddressBook implements Serializable {
    //Resizeable arraylist that keeps track of contact
    //this array is loaded by contacts from file, and then we can perform operations on contacts
    public ArrayList<Address> contactsList = new ArrayList<>(10);

    public AddressBook() { // This constructor deserializes contacts to arraylist.
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(new File("Address Book")))) {
            Address a = null;
            //deserialization
            while((a = (Address) objectInputStream.readObject()) != null){
                contactsList.add(a);
            }
        } catch (Exception e) { }
    }

    public void addContact(Address addContact){ //adding contacts
        contactsList.add(addContact); //adding to arrayList
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File("Address Book")))){
            for(int i = 0; i < contactsList.size() ; i++){
                //Serialization-Writing objects to file. keeping states constant
                objectOutputStream.writeObject(contactsList.get(i));
            }
        } catch (IOException e) { } //Exception Handled But not displayed
    }

    public void displayAddressBook(){
        //Displaying Contacts from list which contains deserialized contacts
        if (contactsList.size() != 0){
            System.out.println("***** Addess Book *****");
            for (int i = 0; i < contactsList.size(); i++)
                System.out.println(contactsList.get(i));
        }else
            System.out.println("***** Empty Address Book *****");

    }
    public void updateContact(String firstname){
        int index = isContactAvailable(firstname);
        if(index != -1){
            System.out.print("Enter Addess to update: ");
            String address = new String(new Scanner(System.in).nextLine());
            contactsList.get(index).address = address;  //updation
            Address updated = contactsList.get(index);
            contactsList.remove(updated); //removing from list
            addContact(updated); //serialization to file
        }
        else
            System.out.println("Contact Not found\n");
    }

    public void searchContact(String firstName){ //searching contact in array list containing serialized objects
        int index = isContactAvailable(firstName);  //fetching index from arraylist
        if(index != -1){  //index validation
            System.out.println("-> Contact Found: ");
            System.out.println(contactsList.get(index)); //contact's address toString() is printed
        }
        else
            System.out.println("Contact not found\n");
    }
    public void deleteContact(String firstName ) throws IOException {// Deleting Contact From serialized File
        int index = isContactAvailable(firstName);  //Fetching index of contact from Array list
        if(index != -1){                                   //Validating index non -1 will be updated
            contactsList.remove(index);                  //removing the the contact from list using index
            ArrayList<Address> updated = contactsList;      //updated contact list
            contactsList = new ArrayList<>(10);       //refreshed back to its state
            if(updated.size() == 0){          //if for single contact deletion file will be refreshed
                File file = new File("Address Book");
                file.delete(); file.createNewFile();         //if for single contact deletion file will bw refreshed
            }//if index is -1 means contact does not exits
            else
                for (int j = 0; j < updated.size(); j++)     //adding contacts to array list and serialized file
                    addContact(updated.get(j));
            System.out.println("**** Deleted Successfully ****");     //success messagae
        }
        else
            System.out.println("Contact Not Found\n"); //if index is -1 contact is not found
        }

    //In order to avoid redundant code this methos will be used for arrayList Traversing
    public int isContactAvailable(String firstName){
        for (int i = 0; i < contactsList.size(); i++)
            if(contactsList.get(i).firsName.equalsIgnoreCase(firstName))
                return i ;//returning index from array list where contact resides.
        return -1; //-1 will be returned if contact does not exists
    }
}
