package Assignment_4;

import java.io.*;

public class Address implements Serializable {

    //State variables
    String firsName;
    String lastName;
    String phoneNumber;
    String address;

    public Address(){} //No arg constructor

    public Address(String fName, String lName, String phoneNumber, String address) {
        this.firsName = fName;
        this.lastName = lName;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }
    @Override
    public String toString(){ //Override special method
        return "\n\tFull Name: "+firsName+" "+lastName+
                "\n\tPhone Number: "+phoneNumber+
                "\n\tAddress: "+address+"\n";
    }
}
