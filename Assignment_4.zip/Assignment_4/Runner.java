package Assignment_4;
import java.io.*;
import java.util.Scanner;
public class Runner {
    //State Variables
    public static final String [] optionsOfAddressBook = {"Enter new Contact","Search Contact","Update Contact","Delete Contact","Display All Contacts\n"};
    public static final Scanner input = new Scanner(System.in); //Scanner input
    static AddressBook addressBook = new AddressBook(); //AddressBook

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        System.out.println("***** Address Book *****");
        int option = -1;
        do {
            for (int i = 1; i <= optionsOfAddressBook.length ; i++)
                System.out.println(i+") "+optionsOfAddressBook[i-1]);
            System.out.print("Option: ");
            option = input.nextInt();
            switch (option) {
                case 1: enterNewContact();break;
                case 2: searchContact();break;
                case 3: updateContact();break;
                case 4: deleteContact();break;
                case 5: addressBook.displayAddressBook();break;
            }
        }while(option != 0);

    }

    private static void enterNewContact()  {  //new Contact Registration
        input.nextLine();
        String fName = getNameInput("firstname");
        String lName = getNameInput("lastname");
        System.out.print("\nPhone Number: ");
        String phoneNumber = input.next() ;
        System.out.print("\nHome Address: ");
        String homeAddress = input.nextLine() + input.nextLine();
        Address address = new Address(fName, lName, phoneNumber, homeAddress);
        addressBook.addContact(address);
        System.out.println("Contact Added Successfully\n");
    }
    private static void searchContact(){  //Running searching module
        input.nextLine();
        String firstname = getNameInput("firstname");
        addressBook.searchContact(firstname);
    }

    private static void updateContact() {   //Running Updating module
        input.nextLine();
        String firstname = getNameInput("firstname");
        addressBook.updateContact(firstname);
        System.out.println("Contact Updated Successfully\n");
    }

    private static void deleteContact() throws IOException {   //deleting module
        input.nextLine();
        String firstname = getNameInput("firstname");
        addressBook.deleteContact(firstname);
    }

    private static String getNameInput(String s) {  //getting firstname that will be used for other modules
        System.out.print("\nEnter "+s+" : ");
        return new String(input.nextLine());

    }
}
